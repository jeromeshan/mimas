import pandas as pd
import numpy as np
from clusterer import Clusterer
from fancyplot import get_clusters_plot

coor=pd.read_csv('ra_dec_z_data.csv')
tmp_coor=coor[['x','y','z']]
tmp_coor=tmp_coor[tmp_coor.x.between(10, 30)]
tmp_coor=tmp_coor[tmp_coor.y.between(-5, 5)]
tmp_coor=tmp_coor[tmp_coor.z.between(-5, 5)]


print(tmp_coor.shape)
clusterer=Clusterer(coefs = 1+1/np.arange(1,100)[20:],max_iter = 30)
labels=clusterer.fit(tmp_coor[['x','y','z']])
get_clusters_plot(clusterer.clusters)
np.save('labes.npy', labels)
