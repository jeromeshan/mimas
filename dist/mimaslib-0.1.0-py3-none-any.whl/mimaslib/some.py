import pandas as pd
import numpy as np
from clusterer import Clusterer
from fancyplot import get_clusters_plot

# coor=pd.read_csv('toy galaxies.csv')
# tmp_coor=coor[['x','y','z']]
# tmp_coor=tmp_coor[tmp_coor.x.between(-200, 200)]
# tmp_coor=tmp_coor[tmp_coor.y.between(-200, 200)]
# tmp_coor=tmp_coor[tmp_coor.z.between(-200, 200)]


# print(tmp_coor.shape)
# clusterer=Clusterer(init_cluster_length=5,coefs = 1+2*1/np.arange(1,100)[1:],max_iter = 30, init_cluster_width= 1,limit_radian = 0.05)
# labels=clusterer.fit(tmp_coor)
# print(labels)
# get_clusters_plot(clusterer.clusters)
# np.save('labes.npy', labels)
coor=pd.read_csv('ra_dec_z_data.csv')
tmp_coor=coor[['x','y','z']]
tmp_coor=tmp_coor[tmp_coor.x.between(10, 30)]
tmp_coor=tmp_coor[tmp_coor.y.between(-10, 10)]
tmp_coor=tmp_coor[tmp_coor.z.between(-10, 10)]


print(tmp_coor.shape)
clusterer=Clusterer(init_cluster_length=0.1,init_cluster_width = 0.1,coefs = 1+1/np.arange(1,100)[10:],max_iter = 30)
labels=clusterer.fit(tmp_coor[['x','y','z']])
get_clusters_plot(clusterer.clusters)