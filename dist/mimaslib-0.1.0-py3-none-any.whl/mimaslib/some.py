import pandas as pd
import numpy as np
from clusterer import Clusterer
from fancyplot import get_clusters_plot
from sklearn.metrics.cluster import adjusted_rand_score

coor=pd.read_csv('toy galaxies.csv')
tmp_coor=coor[['x','y','z','label']]
tmp_coor=tmp_coor[tmp_coor.x.between(-200, 200)]
tmp_coor=tmp_coor[tmp_coor.y.between(-200, 200)]
tmp_coor=tmp_coor[tmp_coor.z.between(-200, 200)]


print(tmp_coor.shape)
clusterer=Clusterer(init_cluster_length=3, init_cluster_width= 2.5, lr = 8, max_iter = 100, limit_radian = 0.05, grow_limit= 3)
labels=clusterer.fit(tmp_coor[['x','y','z']])
print(adjusted_rand_score(tmp_coor.label,labels))

# get_clusters_plot(clusterer.clusters)
# np.save('labes.npy', labels)
# coor=pd.read_csv('ra_dec_z_data.csv')
# tmp_coor=coor[['x','y','z']]
# tmp_coor=tmp_coor[tmp_coor.x.between(40, 200)]
# tmp_coor=tmp_coor[tmp_coor.y.between(-30, 30)]
# tmp_coor=tmp_coor[tmp_coor.z.between(-30, 30)]


# print(tmp_coor.shape)
# clusterer=Clusterer(init_cluster_length=0.01,init_cluster_width = 0.01,limit_radian = 0.01,max_iter = 30,lr = 1, grow_limit= 2)
# labels=clusterer.fit(tmp_coor[['x','y','z']])
# get_clusters_plot(clusterer.clusters)